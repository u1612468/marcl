% Program Listing A.2
% For a given tail probability xi, computes the 𝜉-quantile and ES for the 
% singly noncentral t with 𝑣 degrees of freedom and noncentrality 𝜃.

function [ES, VaR] = nctES(alpha, df, mu)
howfar = nctinv(1e-8,df,mu); % how far into the left tail to integrate
VaR = nctinv(alpha, df, mu); % matlab routine for the quantile
I = quadl(@int ,howfar,VaR,1e-6,[],df,mu);
ES = I/alpha;

function I = int(u,df,mu)
pdf = nctpdf(u,df,mu);
I = u .* pdf;
end

end