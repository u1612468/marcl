function NCTgen = nctgen(mu,df,nobs)
% mu is the noncentrality; and df is degree of freedoms

x = normrnd(mu,1,[nobs 1]);
y = chi2rnd(df,[nobs 1]);
NCTgen =x./sqrt(y./df);

end