rng('default')
loc=1;
scale=2;
df=4;

% compute the true ES
c01 = tinv(0.1, df); 
truec = loc + scale * c01; 
ES01 = -tpdf(c01,df)/tcdf(c01,df) * (df+c01^2)/(df-1);
trueES = loc+scale*ES01;


T = 250; % T = 250,500,1000
sim = 1000;
B = 1000;

P=0.05:0.9:0.95; 

nonpara_es_coverage = zeros(length(P),1);
   para_es_coverage = zeros(length(P),1);
nonparacilength = zeros(length(P),1);
   paracilength = zeros(length(P),1);

ploop=1;
for pvec=P
       para_cilist = zeros(sim,1);
    nonpara_cilist = zeros(sim,1);
    
    for i=1:sim
        
        rand('twister',i)
        data = loc + scale * trnd(df,T,1);
        
        % nonparameter bootstrap 
        alpha = 0.1;
        alphaCI = 0.1;
        ES = @(x)(mean(x(x<=quantile(x,alpha)))); % calculate the empirical ES
        [nonPara_ci,bmeans] = bootci(B,{ES,data},'alpha',alphaCI,'type','per');
        nonpara_coverage(i) = (trueES>=nonPara_ci(1)) & (trueES<=nonPara_ci(2));
        nonpara_ci_length(i) = nonPara_ci(2)-nonPara_ci(1);

        % for parameter bootstrap
        phat = tlikmax0(data,[df loc scale]); % MLE estimators
        mle_df = phat(1);
        mle_loc = phat(2);
        mle_scale = phat(3);

        for b=1:B
            % parametric bootstrap
              data = mle_loc + mle_scale * trnd(mle_df,T,1);
              mleVaR = quantile(data,alpha);
              mletemp = data(data <= mleVaR);
              mle_ES(b) = mean(mletemp);
        end

        para_ci = quantile(mle_ES,[alphaCI/2 1-alphaCI/2]);
        para_coverage(i) = (trueES>=para_ci(1)) & (trueES<=para_ci(2));
        para_ci_length(i) = para_ci(2)-para_ci(1);
    end

       para_es_coverage(ploop) = mean(para_coverage);
    nonpara_es_coverage(ploop) = mean(nonpara_coverage);
       paracilength(ploop) = mean(para_ci_length);
    nonparacilength(ploop) = mean(nonpara_ci_length);
    
    ploop = ploop+1;
end