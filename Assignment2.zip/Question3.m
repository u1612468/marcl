% ES for stable distribution
alpha_stable = 1.6; % 1.6 or 1.8
alpha = 0.1;
[stableES, stableVaR] = asymstableES(alpha, alpha_stable, 0, 0, 1);
trueES_stable = stableES;


sim = 1000;
B = 1000;
T = 100; % T = 100, 500, 2000

P = 0.05:0.9:0.95;
plen=length(P);

nonpara_es_coverage = zeros(plen,1);
   para_es_coverage = zeros(plen,1);
nonparacilength = zeros(plen,1);
   paracilength = zeros(plen,1);
ploop=1;
alphaCI=0.1;

for pvec=P
       para_cilist = zeros(sim,1);
    nonpara_cilist = zeros(sim,1);

    for i=1:sim
        rand('twister',i) 
        stable_data = stablernd(alpha_stable,0,1,0,T,1);

        % nonparameter bootstrap 
        % CI = bootci (NBOOT, BOOTFUN, D) draws nboot bootstrap resamples from the rows
        % of a data sample D and returns confidence intervals CI for the bootstrap 
        % statistics computed by BOOTFUN. To compute bootstrap confidence interval CI 
        % using 'per' or 'percentile': Percentile method.
        q = quantile(stable_data, alpha); 
        nonpara_ES_stable = @(x)(mean(x(x<q)));
        [nonPara_ci,bmeans] = bootci(B,{nonpara_ES_stable,stable_data},'alpha',alphaCI,'type','per');
        nonpara_coverage(i) = (trueES_stable >= nonPara_ci(1)) && (trueES_stable <= nonPara_ci(2));
        nonpara_ci_length(i) = nonPara_ci(2)-nonPara_ci(1);
        
        % parameter bootstrap 
        % MLE
        df = 3;
        loc = 0;
        scale = 1;
        phat = tlikmax0(stable_data,[df loc scale]); % assume regular t distribution
        mle_df = phat(1);
        mle_loc = phat(2);
        mle_scale = phat(3);
        
        for b=1:B
            mledata = mle_loc + mle_scale * trnd(mle_df,T,1);
            mleVaR = quantile(mledata, alpha);
            mletemp = mledata(mledata<=mleVaR);
            para_ES_stable(b) = mean(mletemp);
        end

        para_ci = quantile(para_ES_stable,[alphaCI/2 1-alphaCI/2]);
        para_coverage(i) = (trueES_stable >= para_ci(1)) && (trueES_stable <= para_ci(2));
        para_ci_length(i) = para_ci(2)-para_ci(1);
    end

       para_es_coverage(ploop) = mean(para_coverage);
    nonpara_es_coverage(ploop) = mean(nonpara_coverage);
       paracilength(ploop) = mean(para_ci_length);
    nonparacilength(ploop) = mean(nonpara_ci_length);
    ploop = ploop+1;
end