
df = 3;  % df = 3 or 6
mu = -1; % noncentrality, values are [-3,-2,-1,0]
loc = 1;
scale = 2;
alpha =0.1;
alphaCI = 0.1;

T = 100; % T = 100,500,2000

% true ES
[ES_nct VaR_nct]= nctES(alpha,df,mu); % calculate empirical ES
trueES_nct = loc + scale * ES_nct;

% actual coverage and CI length 
rep=1000;
B=1000;

P=0.05:0.9:0.95;
plen=length(P);

nonpara_es_coverage=zeros(plen,1);
   para_es_coverage=zeros(plen,1);
nonparacilength=zeros(plen,1);
   paracilength=zeros(plen,1);

ploop=1;
for pvec = P
       para_cilist = zeros(rep,1);
    nonpara_cilist = zeros(rep,1);
    
    for i=1:rep

        rand('twister',i)
        datanct01 = nctgen(mu,df,[T 1]);
        datanctls = loc + scale * datanct01;

        % nonparameter bootstrap
        nonpara_ES_nct = @(x)(mean(x(x<quantile(x,alpha))));
        [nonpara_ci, bmeans] = bootci(B,{nonpara_ES_nct,datanctls},'alpha',alphaCI,'type','per');
        nonpara_coverage(i) = (trueES_nct >= nonpara_ci(1)) & (trueES_nct<=nonpara_ci(2));
        nonpara_ci_length(i) = nonpara_ci(2)-nonpara_ci(1);

        % parameter bootstrap
        phat = tlikmax0(datanctls,[df loc scale]); % assume noncentral t as regular t
        mle_df=phat(1);
        mle_loc=phat(2);
        mle_scale=phat(3);
        
        for b=1:B
            mledata = mle_loc + mle_scale * trnd(mle_df,T,1);
            % use trnd since assuming regular t distribution
            mleVaR = quantile(mledata,alpha);
            mletemp = mledata(mledata <= mleVaR);
            para_ES_nct(b) = mean(mletemp);
        end
        
        para_ci = quantile(para_ES_nct,[alphaCI/2 1-alphaCI/2]);
        para_coverage(i) = (trueES_nct>=para_ci(1)) && (trueES_nct<=para_ci(2));
        para_ci_length(i) = para_ci(2)-para_ci(1);
    end

       para_es_coverage(ploop) = mean(para_coverage);
    nonpara_es_coverage(ploop) = mean(nonpara_coverage);
       paracilength(ploop) = mean(para_ci_length);
    nonparacilength(ploop) = mean(nonpara_ci_length);
    ploop = ploop+1;
end