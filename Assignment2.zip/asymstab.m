
function [pdff,cdfF] = asymstab(xvec,a,b)

if nargin<3, b=0; end

bordertol=1e-8; lo= bordertol; hi=1-bordertol; tol =1e-7;
xl=length(xvec);
cdfF=zeros(xl, 1);
pdff =cdfF;

for loop=1:length(xvec)
    x=xvec(loop);
    pdff(loop)=quadl(@fff,lo,hi,tol,[],x,a,b,1)/pi;
    % pdff(loop)=integral(@(uvec) fff(uvec,x,a,b,1),lo,hi,'AbsTol',tol)/pi;
    
    if nargout>1
        % cdfF(loop)=0.5-(1/pi)*integral(@(uvec) fff(uvec,x,a,b,0),lo,hi,'AbsTol',tol);
        cdfF(loop)=0.5-(1/pi)*quadl(@fff,lo,hi,tol,[],x,a,b,0);
    end

end

function I = fff(uvec,x,a,b,dopdf)
subs = 1;
I = zeros(size(uvec));
for ii =1:length(uvec)
    u=uvec(ii);
    if subs==1, t=(1-u)/u; else, t=u/(1 -u); end
    if a==1
        cf = exp(-abs(t)*(1+1i*b*(2/pi)*sign(t)*log(t)));
    else
        cf = exp(-((abs(t))^a)*(1-1i*b*sign(t)*tan(pi*a/2)));
    end

    z = exp(-1i*t*x).*cf;

    if dopdf==1, g=real(z); else, g=imag(z) ./ t; end
    if subs==1, I(ii)=g*u^(-2);
    else, I(ii)=g*(1-u)^(-2) ; end
end

