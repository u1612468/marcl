function MLE = NCTlikmax0(x,initvec)
tol = 1e-5;
opts = optimset('Disp','none','LargeScale','Off', ...
    'TolFun',tol,'TolX',tol,'Maxiter',200);
MLE = fminunc(@(param) NCTloglik(param,x), initvec, opts);
    
    function ll = NCTloglik(param, x)
        dfll  = param(1);
        null = param(2); % the noncentrality
        locll = param(3);
        scalell = param(4);
        
        if dfll < 0.01, dfll = rand; end % An ad hoc way of preventing negative values
        if scalell < 0.01, scalell = rand; end % which works, but is NOT recommended!
        
        z = (x-locll)/scalell;
        ll = log(nctpdf(z,dfll,null)) - log(scalell);
        % ll = stdnctpdfln_j(z,dfll,null)-log(scalell);
        ll = -sum(ll);
    end
end
